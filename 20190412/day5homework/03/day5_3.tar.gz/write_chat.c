#include <headFile.h>
int main(int argc,char *argv[])
{
	int fdw,fdr;
	fdw = open(argv[1],O_WRONLY);
	ERROR_CHECK(fdw,-1,"open");
	fdr = open(argv[2],O_RDONLY);
	ERROR_CHECK(fdr,-1,"open");
	printf("%d%d\n",fdw,fdr);
	char buf[128] = {0};
	while(1)
	{
		//清空
		//默认先读一遍，从当前位置读 0
		//开始写
		//重新清空
		//再次读
		//打印
		memset(buf,0,sizeof(buf));
		read(0,buf,sizeof(buf));
		write(fdw,buf,strlen(buf)-1);
		memset(buf,0,sizeof(buf));
		read(fdr,buf,sizeof(buf));
		printf("%s\n",buf);
	}
	return 0;
}

