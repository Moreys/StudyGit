#include "headFile.h"

int main(int argc,char *argv[])
{
	//先读段则进行先读操作，打开的文件类型也是一样的，先读打开只读文件，后写则打开只写文件
	//创建一个接收的数组
	//循环读取和发送
	//每次读取和写入都要情况缓冲区 
	//每次读取以后都要打印
	int fdw,fdr;
	fdr = open(argv[1],O_RDONLY);
	ERROR_CHECK(fdr,-1,"open");
	fdw = open(argv[2],O_WRONLY);
	ERROR_CHECK(fdw,-1,"open");
	printf("%d %d\n",fdr,fdw);
	char buf[128] = {0};
	while(1)
	{
		memset(buf,0,sizeof(buf));
		read(fdr,buf,sizeof(buf));
		printf("%s\n",buf);
		memset(buf,0,sizeof(buf));
		read(0,buf,sizeof(buf));
		write(fdw,buf,strlen(buf)-1);//每次写入缓冲区大小-1次	
	}
	return 0;
}
